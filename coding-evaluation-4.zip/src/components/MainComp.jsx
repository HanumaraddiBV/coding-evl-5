import { Link } from "react-router-dom"


export const MainComp = ()=>{
    return (<div>
        <Link to="/">Home</Link>
         {/* <Link to="/search/:q=YourQuery">Enter</Link> */}
    </div>)
}